import os
os.chdir('cartoonifier')
os.system('python main.py')